﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;


namespace Top5Tamil.Data
{
    public class TopicItem
    {
        public int TopicItemID { get; set; }
        public string Title { get; set; }
        public string ImagePath { get; set; }
        public string Description { get; set; }
        public string PageTitle { get; set; }
        public int CountOfVotes { get; set; }
        public bool VoteUpButtonVisible { get; set; }
        public bool VoteDownButtonVisible { get; set; }

        public MarkupString MSDescription { get { return (MarkupString)Description; } }

    }
}
