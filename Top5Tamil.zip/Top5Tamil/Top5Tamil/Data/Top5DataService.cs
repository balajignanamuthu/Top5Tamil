﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Identity;

namespace Top5Tamil.Data
{
    public class Top5DataService
    {

        private readonly SQLConnectionConfiguration _Configuration;

        public Top5DataService(SQLConnectionConfiguration configuration)
        {
            _Configuration = configuration;
        }



        public async Task<IEnumerable<TopicItem>> GetTopicData(string TopicName)
        {
            IEnumerable<TopicItem> topicItems;
            IEnumerable<MenuInfo> menuInfos;

            //string connectionstring = "Persist Security Info = False; User ID = top5sqluser1; password = Top5sql$1; Initial Catalog = Top5; Data Source = ADA10616312\\sqlexpress; Connection TimeOut = 100000; ";


            using (var conn = new SqlConnection(_Configuration.Value))
            {
                string query1 = @"exec GetTopicDetails '" + TopicName + "'";

                //const string query1 = @"Select * From MenuInfo";

                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                try
                {
                    topicItems = conn.Query<TopicItem>(query1);
                    //topicItems = (IEnumerable<TopicItem>)menuInfos;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                }

            }

            return topicItems;
        }



        public async Task CastVote(int TopicItemID, int UserID)
        {




            using (var conn = new SqlConnection(_Configuration.Value))
            {
                string query1 = @"INSERT INTO DBO.TopicItemVotes VALUES (  "
                                                                            + TopicItemID.ToString()
                                                                            + ", " + UserID
                                                                            + ", '" + DateTime.Now.ToString() + "'"
                                                                            + ", " + UserID
                                                                            + ", '" + DateTime.Now.ToString() + "'"
                                                                            + ", " + UserID
                                                                            + ", '" + DateTime.Now.ToString() + "'"
                                                                            + ")";

                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                try
                {
                    await conn.ExecuteScalarAsync(query1);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                }

            }

        }

        public async Task<string> GetPageTitle(string TopicName)
        {
            string PageTitle = "";

            using (var conn = new SqlConnection(_Configuration.Value))
            {
                string query = @"SELECT TOP 1 MI.PageTitle FROM MenuInfo MI INNER JOIN TopicItem TI ON MI.MenuID = TI.MenuID WHERE TI.TopicName = '" + TopicName + "'";

                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                try
                {
                    var PageTitle1 = await conn.QueryAsync(query);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                }

            }

            return PageTitle;
        }


        public string GetUserName(string Email)
        {
            string UserName = "";

            using (var conn = new SqlConnection(_Configuration.Value))
            {
                string query = @"SELECT UserName FROM AspNetUsers WHERE Email = '" + Email + "'";

                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                try
                {
                    UserName = conn.ExecuteScalar(query).ToString();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                }

            }
            return UserName;
        }

    }
}
