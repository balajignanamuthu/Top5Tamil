﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Components;

namespace Top5Tamil.Data
{
    public class MenuService
    {
        private readonly SQLConnectionConfiguration _Configuration;

        public MenuService(SQLConnectionConfiguration configuration)
        {
            _Configuration = configuration;
        }

        public async Task<IEnumerable<MenuInfo>> GetMenuData()
        {
            IEnumerable<MenuInfo> menuInfos;

            using (var conn = new SqlConnection(_Configuration.Value))
            {
                const string query = @"Select * From MenuInfo";

                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                try
                {
                    menuInfos = await conn.QueryAsync<MenuInfo>(query);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                        conn.Close();

                }

            }

            return menuInfos;
        }
    }
}
