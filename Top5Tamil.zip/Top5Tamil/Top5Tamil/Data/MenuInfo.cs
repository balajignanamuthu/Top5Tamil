﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Top5Tamil.Data
{
    public class MenuInfo
    {
        public int MenuID { get; set; }
        public int ParentMenuID { get; set; }
        public string PageName { get; set; }
        public string MenuName { get; set; }
        public string IconName { get; set; }
    }
}
